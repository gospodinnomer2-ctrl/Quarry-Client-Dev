package quarry.module;

import net.minecraft.client.MinecraftClient;

public class AutoSprintModule extends Module {
    public AutoSprintModule() {
        super("AutoSprint", false);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.currentScreen != null) {
            return;
        }

        boolean movingForward = client.options.forwardKey.isPressed();
        boolean sneaking = client.options.sneakKey.isPressed();

        if (movingForward && !sneaking && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }
    }
}
