package quarry.module;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public final class ModuleManager {
    public static final AutoSprintModule AUTO_SPRINT = new AutoSprintModule();
    public static final NoFireModule NO_FIRE = new NoFireModule();

    private static final List<Module> MODULES = List.of(AUTO_SPRINT, NO_FIRE);

    private ModuleManager() {
    }

    public static void init() {
        // Module instances are created when this class loads.
    }

    public static List<Module> getModules() {
        return MODULES;
    }

    public static void tick(MinecraftClient client) {
        for (Module module : MODULES) {
            if (module.isEnabled()) {
                module.onTick(client);
            }
        }
    }
}
