package quarry.module;

public class NoFireModule extends Module {
    public NoFireModule() {
        super("NoFire", true);
    }
}
