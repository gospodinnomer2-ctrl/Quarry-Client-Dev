package quarry.screen;

import quarry.module.Module;
import quarry.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class QuarryScreen extends Screen {
    public QuarryScreen() {
        super(Text.literal("Quarry"));
    }

    @Override
    protected void init() {
        int buttonWidth = 180;
        int x = (this.width - buttonWidth) / 2;
        int y = Math.max(45, this.height / 4);

        for (Module module : ModuleManager.getModules()) {
            addDrawableChild(ButtonWidget.builder(moduleText(module), button -> {
                module.toggle();
                button.setMessage(moduleText(module));
            }).dimensions(x, y, buttonWidth, 20).build());
            y += 25;
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(x, y + 8, buttonWidth, 20)
                .build());
    }

    private Text moduleText(Module module) {
        return Text.literal(module.getName() + ": " + (module.isEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, "QUARRY", width / 2, 20, 0xFFB58CFF);
        context.drawCenteredTextWithShadow(textRenderer, "Right Shift - menu | G - AutoSprint | H - NoFire",
                width / 2, 34, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
