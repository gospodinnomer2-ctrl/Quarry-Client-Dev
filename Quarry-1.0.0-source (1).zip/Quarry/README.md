# Quarry

Client-side visual/QoL mod for **Minecraft Java 1.21.4 + Fabric**.

## First build

- Java 21
- Fabric Loader 0.16.10
- Fabric API 0.119.4+1.21.4
- Yarn 1.21.4+build.8
- Fabric Loom 1.9

## Current modules

- **NoFire** — hides the first-person fire overlay. Enabled by default.
- **AutoSprint** — automatically sprints while the forward key is held and the player can sprint.
- **ClickGUI** — press Right Shift to open the Quarry menu.

## Default keybinds

- Right Shift: open menu
- G: toggle AutoSprint
- H: toggle NoFire

All modules are client-side. This is an initial foundation; additional visual modules will be added in later versions.
